package com.example.appcocina4

import android.text.Editable

data class Comentario(var text: String? = null, var user: String? = null) {
}