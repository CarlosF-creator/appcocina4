package com.example.appcocina4

data class Instrucciones(var paso1: String? = null,
                         var paso2: String? = null,
                         var paso3: String? = null,
                         var paso4: String? = null,
                         var paso5: String? = null,
                         var paso6: String? = null,
                         var paso7: String? = null,
                         var paso8: String? = null,
                         var paso9: String? = null,
                         var paso10: String? = null,
                         var paso11: String? = null,
                         var paso12: String? = null,
                         var paso13: String? = null,
                         var paso14: String? = null,
                         var paso15: String? = null,
                         var paso16: String? = null,
                         var paso17: String? = null,
                         var paso18: String? = null,
                         var paso19: String? = null,
                         var paso20: String? = null,
                         var paso21: String? = null,
                         var paso22: String? = null,
                         var paso23: String? = null,
                         var paso24: String? = null,
                         var paso25: String? = null,
                         var paso26: String? = null,
                         var paso27: String? = null,
                         var paso28: String? = null,
                         var paso29: String? = null,
                         var paso30: String? = null,
                         var paso31: String? = null,
                         var paso32: String? = null,
                         var paso33: String? = null,
                         var paso34: String? = null,
                         var paso35: String? = null,
                         var paso36: String? = null,
                         var paso37: String? = null,
                         var paso38: String? = null,
                         var paso39: String? = null,
                         var paso40: String? = null,
                         ){

    fun get(paso : String):String?{
        if (paso == "paso1"){
            return this.paso1
        }
        if (paso == "paso2"){
            return this.paso2
        }
        if (paso == "paso3"){
            return this.paso3
        }
        if (paso == "paso4"){
            return this.paso4
        }
        if (paso == "paso5"){
            return this.paso5
        }
        if (paso == "paso6"){
            return this.paso6
        }
        if (paso == "paso7"){
            return this.paso7
        }
        if (paso == "paso8"){
            return this.paso8
        }
        if (paso == "paso9"){
            return this.paso9
        }
        if (paso == "paso10"){
            return this.paso10
        }
        if (paso == "paso11"){
            return this.paso11
        }
        if (paso == "paso12"){
            return this.paso12
        }
        if (paso == "paso13"){
            return this.paso13
        }
        if (paso == "paso14"){
            return this.paso14
        }
        if (paso == "paso15"){
            return this.paso15
        }
        if (paso == "paso16"){
            return this.paso16
        }
        if (paso == "paso17"){
            return this.paso17
        }
        if (paso == "paso18"){
            return this.paso18
        }
        if (paso == "paso19"){
            return this.paso19
        }
        if (paso == "paso20"){
            return this.paso20
        }
        if (paso == "paso21"){
            return this.paso21
        }
        if (paso == "paso22"){
            return this.paso22
        }
        if (paso == "paso23"){
            return this.paso23
        }
        if (paso == "paso24"){
            return this.paso24
        }
        if (paso == "paso25"){
            return this.paso25
        }
        if (paso == "paso26"){
            return this.paso26
        }
        if (paso == "paso27"){
            return this.paso27
        }
        if (paso == "paso28"){
            return this.paso28
        }
        if (paso == "paso29"){
            return this.paso29
        }
        if (paso == "paso30"){
            return this.paso30
        }
        if (paso == "paso31"){
            return this.paso31
        }
        if (paso == "paso32"){
            return this.paso32
        }
        if (paso == "paso33"){
            return this.paso33
        }
        if (paso == "paso34"){
            return this.paso34
        }
        if (paso == "paso35"){
            return this.paso35
        }
        if (paso == "paso36"){
            return this.paso36
        }
        if (paso == "paso37"){
            return this.paso37
        }
        if (paso == "paso38"){
            return this.paso38
        }
        if (paso == "paso39"){
            return this.paso39
        }
        if (paso == "paso40"){
            return this.paso40
        }



        return  null

    }

    fun set(paso : String, newpaso: String){
        if (paso == "paso1"){
            this.paso1 =newpaso
        }
        if (paso == "paso2"){
             this.paso2 =newpaso
        }
        if (paso == "paso3"){
             this.paso3 =newpaso
        }
        if (paso == "paso4"){
             this.paso4 =newpaso
        }
        if (paso == "paso5"){
             this.paso5 =newpaso
        }
        if (paso == "paso6"){
             this.paso6 =newpaso
        }
        if (paso == "paso7"){
             this.paso7 =newpaso
        }
        if (paso == "paso8"){
             this.paso8 =newpaso
        }
        if (paso == "paso9"){
             this.paso9 =newpaso
        }
        if (paso == "paso10"){
             this.paso10 =newpaso
        }
        if (paso == "paso11"){
             this.paso11 =newpaso
        }
        if (paso == "paso12"){
             this.paso12 =newpaso
        }
        if (paso == "paso13"){
             this.paso13 =newpaso
        }
        if (paso == "paso14"){
             this.paso14 =newpaso
        }
        if (paso == "paso15"){
             this.paso15 =newpaso
        }
        if (paso == "paso16"){
             this.paso16 =newpaso
        }
        if (paso == "paso17"){
             this.paso17 =newpaso
        }
        if (paso == "paso18"){
             this.paso18 =newpaso
        }
        if (paso == "paso19"){
             this.paso19 =newpaso
        }
        if (paso == "paso20"){
             this.paso20 =newpaso
        }
        if (paso == "paso21"){
             this.paso21 =newpaso
        }
        if (paso == "paso22"){
             this.paso22 =newpaso
        }
        if (paso == "paso23"){
             this.paso23 =newpaso
        }
        if (paso == "paso24"){
             this.paso24 =newpaso
        }
        if (paso == "paso25"){
             this.paso25 =newpaso
        }
        if (paso == "paso26"){
             this.paso26 =newpaso
        }
        if (paso == "paso27"){
             this.paso27 =newpaso
        }
        if (paso == "paso28"){
             this.paso28 =newpaso
        }
        if (paso == "paso29"){
             this.paso29 =newpaso
        }
        if (paso == "paso30"){
             this.paso30 =newpaso
        }
        if (paso == "paso31"){
             this.paso31 =newpaso
        }
        if (paso == "paso32"){
             this.paso32 =newpaso
        }
        if (paso == "paso33"){
             this.paso33 =newpaso
        }
        if (paso == "paso34"){
             this.paso34 =newpaso
        }
        if (paso == "paso35"){
             this.paso35 =newpaso
        }
        if (paso == "paso36"){
             this.paso36 =newpaso
        }
        if (paso == "paso37"){
             this.paso37 =newpaso
        }
        if (paso == "paso38"){
             this.paso38 =newpaso
        }
        if (paso == "paso39"){
             this.paso39 =newpaso
        }
        if (paso == "paso40"){
             this.paso40 =newpaso
        }

    }


}